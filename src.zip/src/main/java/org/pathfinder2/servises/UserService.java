package org.pathfinder2.servises;

import org.springframework.stereotype.Service;

@Service
public interface UserService {
}
