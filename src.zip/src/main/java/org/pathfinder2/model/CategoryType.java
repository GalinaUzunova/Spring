package org.pathfinder2.model;

public enum CategoryType {
    PEDESTRIAN , BICYCLE, MOTORCYCLE , CAR
}
