package org.pathfinder2.model;

public enum UserRole {
    USER, MODERATOR , ADMIN
}
