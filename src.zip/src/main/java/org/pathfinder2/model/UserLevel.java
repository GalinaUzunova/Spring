package org.pathfinder2.model;

public enum UserLevel {
    BEGINNER, INTERMEDIATE, ADVANCED
}
