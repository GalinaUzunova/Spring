package org.pathfinder2.model;

public enum Level {
    BEGINNER, INTERMEDIATE, ADVANCED
}
